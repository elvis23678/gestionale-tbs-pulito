Gestionale TBS — nuovo progetto pulito

Carica nel nuovo repository:
- app.py
- requirements.txt

Render:
Build Command: pip install -r requirements.txt
Start Command: gunicorn app:app

Variabili:
PYTHON_VERSION = 3.12.11
SECRET_KEY = una stringa casuale
ADMIN_USERNAME = il tuo nome utente
ADMIN_PASSWORD = la tua password

Questa versione non usa cartelle static o templates.
